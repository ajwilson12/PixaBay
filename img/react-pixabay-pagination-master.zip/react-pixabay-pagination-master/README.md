# Images width pixabay and pagination

<p>Simple app that use pixabay api with pagination.</p>

<b>Preview</b>
https://react-pixabay-pagination.vercel.app/

<img src='https://repository-images.githubusercontent.com/346763496/9eef0a00-825c-11eb-83c0-33cb16722fce' alt='api pixabay' />
